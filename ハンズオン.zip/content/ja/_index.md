---
title: GitHub Copilot ハンズオン
---


GitHub Copilotは、AIを活用したコーディングアシスタントであり、効率的にコードを記述することができます。このハンズオン資料では、GitHub Copilotの基本的な使い方から応用的な活用方法までを学ぶことができます。以下のような章構成になっています。

このハンズオン資料を通じて、GitHub Copilotを最大限に活用し、開発作業の効率と品質を向上させる方法を学ぶことができます。

{{ range .Pages }}
- [{{ .Title }}]({{ .Permalink }})
{{ end }}