---
title: うまく指示を出すコツ
categories: [業務利活用]
weight: 3
---

GitHub Copilot に指示を出す際の効率的なプロンプトの書き方や、ヒントを紹介します。
